function alertExternal(){
    alert('Hello guys');
    document.body.style.backgroundColor="red";
    document.getElementById('btn1').style.backgroundColor="blue";
}
function confirmExternal(){
    confirm('Are You Sure');
    document.body.style.backgroundColor="brown";
    document.getElementById('btn2').style.backgroundColor="blue";
}
function promptExternal(){
    prompt('Enter your name');
    document.body.style.backgroundColor="green";
    document.getElementById('btn3').style.backgroundColor="blue";
}
console.log("Hello");
function b1(){
    document.body.style.backgroundColor=prompt('Enter your color');
}
function b2(){
    document.body.style.backgroundColor="green";
    document.getElementById('b2').style.backgroundColor= prompt('Enter your color');
}
function b3(){
    document.body.style.backgroundColor=document.getElementById('b3').value;
}

function button1(){
    document.getElementById('div1').style.backgroundColor=document.getElementById('button1').value     ;


}
function btn21(){
    var x=prompt('enter your name')
    document.getElementById('btn22').innerHTML=x;

}
function btn23(){
    var x=prompt('enter your name')
    document.getElementById('btn23').innerHTML=x;

}
function btn24(){
    var x=prompt('enter your Firstname')
    document.getElementById('btn25').innerHTML=x;
    var y=prompt('enter your lastname')
    document.getElementById('btn26').innerHTML=y;

}