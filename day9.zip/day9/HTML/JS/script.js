function img1(){
    document.getElementById("C3").src="../IMAGE/images.jpg";
}