function my(){
    document.getElementById("h1").style.fontSize="100px";

}
function hello(){
    document.getElementById("h1").style.fontFamily="Impact,Charcoal,sans-serif";

}
function hii(){
    document.getElementById("h1").style.display="none";

}