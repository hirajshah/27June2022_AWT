function bg(){
    document.getElementById('body').style.backgroundImage="linear-gradient(rgb(98, 67, 143),RGB(29, 225, 222))";

}

$(document).ready(function(){
    $("#r2c2").hide();
    $("#r2c3").hide();
    $("#less").hide();
    $("#seemore").click(function(){
        $("#r2c2").show(1000);
        $("#r2c3").show(1000);
        $("#seemore").hide();
        $("#less").show();
    });
    $("#less").click(function(){
        $("#r2c2").hide(1000);
        $("#r2c3").hide(1000);
        $(this).hide();
        $("#seemore").show();
    });
});