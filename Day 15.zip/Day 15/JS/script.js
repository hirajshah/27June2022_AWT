$(document).ready(function() {
    $( "#draggable" ).draggable();
    $( "#droppable" ).droppable({
      drop: function( event, ui ) {
        $( this )
          .addClass( "ui-state-highlight" )
          .find( "p" )
            .html( "Dropped!" );
      }
    });
    $("#div3").resizable();
    $("#sort1").sortable();
    $("#sort2").sortable();
    $("#sort1").sortable({
        connectWith: "#sort2 , #sort1"
    });
    $("#sort2").sortable({
        connectWith: "#sort1 , #sort2"
    });
});